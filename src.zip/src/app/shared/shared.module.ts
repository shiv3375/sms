import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FetchdeptPipe } from './pipe/fetchdept.pipe';

@NgModule({
  declarations: [FetchdeptPipe],
  exports: [FetchdeptPipe],
  imports: [CommonModule],
})
export class SharedModule {}

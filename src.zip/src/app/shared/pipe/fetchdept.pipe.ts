import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'fetchdept'
})
export class FetchdeptPipe implements PipeTransform {

  transform(value: any): any {
    if (typeof value !== 'string') {
      return value;
    }

    // Split the string into individual words
    const words = value.trim().split(' ');

    // Get the first character of each word and convert to uppercase
    const acronym = words.map(word => word[0].toUpperCase()).join('');

    return acronym;
  }

}

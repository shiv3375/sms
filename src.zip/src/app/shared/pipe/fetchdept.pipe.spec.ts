import { FetchdeptPipe } from './fetchdept.pipe';

describe('FetchdeptPipe', () => {
  it('create an instance', () => {
    const pipe = new FetchdeptPipe();
    expect(pipe).toBeTruthy();
  });
});

import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {MatButtonModule} from '@angular/material/button';
import { StudentModule } from './student/student.module';
import { SharedModule } from '../shared/shared.module';
import { FetchdeptPipe } from '../shared/pipe/fetchdept.pipe';


@NgModule({
  declarations: [StudentModule],
  imports: [
    CommonModule,
    MatButtonModule,
    SharedModule,
    FetchdeptPipe
   
  ]
})
export class FeaturedModule { }

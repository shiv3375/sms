import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { StudentComponent } from './components/studentList/student.component';
import { StudentDetailsComponent } from './components/student-details/student-details.component';
import { SharedModule } from 'src/app/shared/shared.module';


@NgModule({
  declarations: [StudentComponent, StudentDetailsComponent, ],
  imports: [CommonModule, SharedModule],
})
export class StudentModule {}

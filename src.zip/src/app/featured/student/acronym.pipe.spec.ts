import { AcronymPipe } from './acronym.pipe';

describe('AcronymPipe', () => {
  it('create an instance', () => {
    const pipe = new AcronymPipe();
    expect(pipe).toBeTruthy();
  });
});

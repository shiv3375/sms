export interface Student {
  name: string;
  id: number;
  dept:{
    id: number,
    dept_name: string,
    HOD: string
  };
  DOB: string;
  DOJ: string;
  semester: number;
  grade: number;
  cityId: number;
}

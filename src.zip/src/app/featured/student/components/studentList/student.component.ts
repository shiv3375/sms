import { Component, OnInit, OnDestroy } from '@angular/core';
import { Student } from '../../models/student';
import { StudentService } from '../../services/student.service';
import { Subscription } from 'rxjs';
import { LocationService } from 'src/app/core/services/location.service';
@Component({
  selector: 'app-student',
  
  templateUrl: './student.component.html',
  styleUrls: ['./student.component.css'],
})
export class StudentComponent implements OnInit, OnDestroy {
  students: Student[] = [];
  cityId: number | null = null;
  private subscription: Subscription = new Subscription();

  constructor(private studentService: StudentService, private locationService: LocationService) {}

  ngOnInit(): void {
    this.subscription = this.locationService.getLocationId().subscribe((data) => {
      this.cityId = data;
      this.getStudentByCityId();
    });
  }

  getStudentByCityId(): void {
    if (this.cityId !== null) {
      this.studentService.getStudentByCityId(this.cityId).subscribe(
        (students) => {
          // console.log("hello fro std ");
          
          this.students = students;
          console.log(this.students);
          
        },
        (error) => {
          console.error('Error fetching students', error);
          alert('Error fetching students');
        }
      );
    }
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }
}

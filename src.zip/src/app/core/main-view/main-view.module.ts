import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SidenavComponent } from './components/sidenav/sidenav.component';
import { LocationComponent } from './components/location/location.component';
import { StudentComponent } from 'src/app/featured/student/components/studentList/student.component';
import {MatSidenavModule} from '@angular/material/sidenav';


@NgModule({
  declarations: [
    SidenavComponent,
    LocationComponent,
    StudentComponent
  ],
  imports: [
    CommonModule,
    MatSidenavModule
  ]
})
export class MainViewModule { }

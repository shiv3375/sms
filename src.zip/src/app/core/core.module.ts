import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { StudentComponent } from '../featured/student/components/studentList/student.component';
import {FormsModule} from '@angular/forms';
// import { Location } from './main-view/models/location';
import { LocationComponent } from './main-view/components/location/location.component';


@NgModule({
  declarations: [LocationComponent],
  imports: [
    CommonModule,
    StudentComponent,
    FormsModule

  ]
})
export class CoreModule { }
